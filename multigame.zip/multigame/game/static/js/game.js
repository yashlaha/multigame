$(document).ready(function(){

	$("#begingame").on('click',function(){
	//console.log("here");
	$('#newGame').modal('show');
});

});
